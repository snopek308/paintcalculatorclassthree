
public class Fence implements Paintable {

    @Override
    public double getPremiumCost() {
        return 25;
    }

    @Override
    public double getStandardCost() {
        return 10;
    }
    
}
