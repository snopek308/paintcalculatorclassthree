
public class Paintbrush<T> {
    private T color;
    
    public Paintbrush(T color){
        this.color = color;
    }
    
}
