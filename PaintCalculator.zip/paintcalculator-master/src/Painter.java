
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javafx.scene.paint.Color;


public class Painter {
    public static void main(String[] args) {
        Paintbrush<String>pb1 = new Paintbrush<String>("red");
        Paintbrush<Color>pb2 = new Paintbrush<Color>(Color.CYAN);
        Paintbrush<Triplet<Integer>>pb3 = new Paintbrush<Triplet<Integer>>(new Triplet<Integer>());
        
        List<Paintbrush>pbList = new ArrayList();
        
        Map<String, String> animalFoodMap = new HashMap<String, String>();
        
        animalFoodMap.put("chicken", "corn");
        animalFoodMap.put("pigs", "bacon");
        animalFoodMap.put("teenager", "pizza");
        
        String key = "pigs";
        
        animalFoodMap.get("chicken");
        
        animalFoodMap.containsKey("cow");
        
        Map<Color, Paintbrush> brushes = new HashMap();
        brushes.put(Color.CYAN, pb2);
    }
}
